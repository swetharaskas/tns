package corejava;

public class Protectedp1 {
	protected void display3()
	{
		System.out.println("protected access specifier");
	}
	
	
	
	
	
	
}
