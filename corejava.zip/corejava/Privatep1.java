package corejava;

public class Privatep1 {
	private void display2() {
		System.out.println("private access specifier");
	}
public static void main(String[]args) {
Privatep1 obj3 = new Privatep1();
obj3 . display2();
}
}
