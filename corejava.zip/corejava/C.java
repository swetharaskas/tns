package corejava;

public class C {
	   int i=4;
		static int b=4;
		int display() 
		{
			return 1;
		}
		static void display1() {
			System.out.println("12");
		}
	public static void main(String[] args)
	{
		int j=3;
		System.out.println(j);
		C c1= new C();
		System.out.println(c1.i);
		c1.display();
		System.out.println(C.b);
		C.display1();
		
	}
	}


