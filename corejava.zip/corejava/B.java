package corejava;

public class B {
	
	public static void main(String[] args) {
		int d=5;
		 System.out.println(d);
		 A  obj = new A();
		 System.out.println(obj.a);
		 
		 
		 
		 obj .display();
		 System.out.println(A.b);
		
		 
	}

}
