package corejava;

public class Protectedp2 extends Protectedp1 {
	
public static void main(String[]args)
{
	Protectedp1 obj4 = new Protectedp1();
	obj4.display3();
}
}
